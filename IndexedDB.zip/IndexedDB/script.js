// Membuka atau membuat database IndexedDB
const request = indexedDB.open('MyDatabase', 1);
let db;
let selectedId;

request.onsuccess = function (event) {
    db = event.target.result;
    readData();
};

request.onerror = function (event) {
    console.error("Database error: " + event.target.error);
};

request.onupgradeneeded = function (event) {
    db = event.target.result;
    const objectStore = db.createObjectStore('MyData', { keyPath: 'id', autoIncrement: true });
    objectStore.createIndex('name', 'name', { unique: false });
    objectStore.createIndex('nim', 'nim', { unique: true });
};

// Fungsi untuk menambahkan data
function addData(name, nim) {
    const transaction = db.transaction(['MyData'], 'readwrite');
    const objectStore = transaction.objectStore('MyData');
    const data = { name: name, nim: nim };

    const request = objectStore.add(data);

    request.onsuccess = function () {
        console.log('Data telah ditambahkan.');
        readData();
        document.getElementById('dataForm').reset();
    };

    request.onerror = function (event) {
        console.error('Gagal menambahkan data: ' + event.target.error);
    };
}

// Fungsi untuk membaca data
function readData() {
    const transaction = db.transaction(['MyData'], 'readonly');
    const objectStore = transaction.objectStore('MyData');
    const dataList = document.getElementById('dataList');

    dataList.innerHTML = '';

    const request = objectStore.openCursor();

    request.onsuccess = function (event) {
        const cursor = event.target.result;
        if (cursor) {
            const rowData = cursor.value;
            const row = document.createElement('tr');
            row.innerHTML = '<td>' + cursor.key + '</td>' +
                '<td contenteditable="true" onblur="updateDataName(' + cursor.key + ', this)" data-name="' + rowData.name + '">' + rowData.name + '</td>' +
                '<td contenteditable="true" onblur="updateDataNIM(' + cursor.key + ', this)" data-nim="' + rowData.nim + '">' + rowData.nim + '</td>' +
                '<td><button class="edit-button" onclick="editData(' + cursor.key + ')">Edit</button> ' +
                '<button class="delete-button" onclick="deleteData(' + cursor.key + ')">Hapus</button></td>';
            dataList.appendChild(row);
            cursor.continue();
        }
    };
}

// Fungsi untuk mengupdate data "Nama"
function updateDataName(id, element) {
    const newName = element.textContent;
    const transaction = db.transaction(['MyData'], 'readwrite');
    const objectStore = transaction.objectStore('MyData');

    const request = objectStore.get(id);

    request.onsuccess = function () {
        const data = request.result;
        data.name = newName;
        const updateRequest = objectStore.put(data);

        updateRequest.onsuccess = function () {
            console.log('Data "Nama" telah diperbarui.');
        };

        updateRequest.onerror = function (event) {
            console.error('Gagal memperbarui data "Nama": ' + event.target.error);
        };
    };
}

// Fungsi untuk mengupdate data "NIM"
function updateDataNIM(id, element) {
    const newNIM = element.textContent;
    const transaction = db.transaction(['MyData'], 'readwrite');
    const objectStore = transaction.objectStore('MyData');

    const request = objectStore.get(id);

    request.onsuccess = function () {
        const data = request.result;
        data.nim = newNIM;
        const updateRequest = objectStore.put(data);

        updateRequest.onsuccess = function () {
            console.log('Data "NIM" telah diperbarui.');
        };

        updateRequest.onerror = function (event) {
            console.error('Gagal memperbarui data "NIM": ' + event.target.error);
        };
    };
}

// Fungsi untuk mengedit data
function editData(id) {
    const transaction = db.transaction(['MyData'], 'readonly');
    const objectStore = transaction.objectStore('MyData');
    selectedId = id;

    const request = objectStore.get(id);

    request.onsuccess = function () {
        const data = request.result;
        document.getElementById('editName').value = data.name;
        document.getElementById('editNIM').value = data.nim;
        document.getElementById('editModal').style.display = 'block';
    };
}

// Fungsi untuk menyimpan perubahan data dari modal
function saveEditedData() {
    const newName = document.getElementById('editName').value;
    const newNIM = document.getElementById('editNIM').value;

    const transaction = db.transaction(['MyData'], 'readwrite');
    const objectStore = transaction.objectStore('MyData');

    const request = objectStore.get(selectedId);

    request.onsuccess = function () {
        const data = request.result;
        data.name = newName;
        data.nim = newNIM;
        const updateRequest = objectStore.put(data);

        updateRequest.onsuccess = function () {
            console.log('Data telah diperbarui.');
            readData();
            document.getElementById('editModal').style.display = 'none';
        };

        updateRequest.onerror = function (event) {
            console.error('Gagal memperbarui data: ' + event.target.error);
        };
    };
}

// Fungsi untuk membatalkan pengeditan dan menutup modal
function cancelEdit() {
    document.getElementById('editModal').style.display = 'none';
}

// Fungsi untuk menghapus data
function deleteData(id) {
    const transaction = db.transaction(['MyData'], 'readwrite');
    const objectStore = transaction.objectStore('MyData');

    const request = objectStore.delete(id);

    request.onsuccess = function () {
        console.log('Data telah dihapus.');
        readData();
    };

    request.onerror = function (event) {
        console.error('Gagal menghapus data: ' + event.target.error);
    };
}

// Event listener untuk form pengiriman data
document.getElementById('dataForm').addEventListener('submit', function (event) {
    event.preventDefault();
    const name = document.getElementById('name').value;
    const nim = document.getElementById('nim').value;
    if (name && nim) {
        addData(name, nim);
    }
});